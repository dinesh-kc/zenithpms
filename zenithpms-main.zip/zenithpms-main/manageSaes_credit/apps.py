from django.apps import AppConfig


class ManagesaesCreditConfig(AppConfig):
    name = 'manageSaes_credit'

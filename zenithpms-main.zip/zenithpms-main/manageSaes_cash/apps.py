from django.apps import AppConfig


class ManagesaesCashConfig(AppConfig):
    name = 'manageSaes_cash'

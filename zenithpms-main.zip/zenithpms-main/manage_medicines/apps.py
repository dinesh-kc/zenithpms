from django.apps import AppConfig


class ManageMedicinesConfig(AppConfig):
    name = 'manage_medicines'

from django.apps import AppConfig


class AutomatefileConfig(AppConfig):
    name = 'automateFile'

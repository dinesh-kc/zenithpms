from django.apps import AppConfig


class OrdermedicineConfig(AppConfig):
    name = 'orderMedicine'
